package com.mathcraft.studio;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public final class MainActivity extends Activity {
    private static final int PICK_FOLDER = 201;
    private static final int PICK_ARCHIVE = 202;
    private static final int PICK_BROWSER_FILE = 203;
    private static final int SAVE_EXPORT = 204;
    private static final int MAX_FILES = 10000;
    private static final int MAX_ARCHIVES = 80;
    private static final long MAX_ARCHIVE_SIZE = 370L * 1024 * 1024;
    private static final long MAX_TEXTURE_SIZE = 12L * 1024 * 1024;
    private static final String PREFS = "mathcraft_android_store";
    private WebView web;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Object catalogLock = new Object();
    private final List<Source> sources = new ArrayList<>();
    private final List<Texture> textures = new ArrayList<>();
    private final Map<String, File> exports = new HashMap<>();
    private Uri chosenTree;
    private ValueCallback<Uri[]> fileChooser;
    private File pendingExport;
    private boolean webReady = false;
    private volatile int generation = 0;

    private static final class Source {
        String id;
        String title;
        List<String> paths = new ArrayList<>();
        File archive;
    }
    private static final class Texture {
        File archive;
        String path;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        setContentView(web);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccessFromFileURLs(false);
        web.getSettings().setAllowUniversalAccessFromFileURLs(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (url.startsWith("file:///android_asset/")) {
                    webReady = true;
                    inject("window.MathCraftAndroidLibrary&&window.MathCraftAndroidLibrary.onLibraryChanged();");
                }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !request.getUrl().toString().startsWith("file:///android_asset/");
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileChooser != null) fileChooser.onReceiveValue(null);
                fileChooser = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, PICK_BROWSER_FILE);
                    return true;
                } catch (Exception ex) {
                    fileChooser = null;
                    return false;
                }
            }
        });
        web.addJavascriptInterface(new Bridge(), "MathCraftAndroid");
        web.loadUrl("file:///android_asset/index.html");
        loadPermission();
        handleSharedFile(getIntent());
    }

    private void inject(String code) {
        main.post(() -> { if (webReady && !isFinishing()) web.evaluateJavascript(code, null); });
    }
    private void status(String message) {
        inject("window.MathCraftAndroidLibrary&&window.MathCraftAndroidLibrary.status(" + JSONObject.quote(message) + ");");
    }
    private void toast(String message) {
        main.post(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show());
    }
    private void loadPermission() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        String tree = p.getString("tree", null);
        if (tree != null) {
            chosenTree = Uri.parse(tree);
            executor.execute(() -> scanFolder(chosenTree));
        }
        Set<String> archives = p.getStringSet("archives", Collections.emptySet());
        for (String s : archives) executor.execute(() -> indexUri(Uri.parse(s), false));
    }

    private void openFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_FOLDER);
    }
    private void openArchives() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_ARCHIVE);
    }
    private void handleSharedFile(Intent intent) {
        if (intent != null && Intent.ACTION_SEND.equals(intent.getAction())) {
            Uri shared = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (shared != null) executor.execute(() -> indexUri(shared, false));
        }
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleSharedFile(intent);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_BROWSER_FILE) {
            if (fileChooser != null) {
                Uri[] chosen = (result == RESULT_OK) ? WebChromeClient.FileChooserParams.parseResult(result, data) : null;
                fileChooser.onReceiveValue(chosen);
                fileChooser = null;
            }
            return;
        }
        if (result != RESULT_OK || data == null) return;
        if (request == PICK_FOLDER) {
            Uri uri = data.getData();
            if (uri == null) return;
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                chosenTree = uri;
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("tree", uri.toString()).apply();
                executor.execute(() -> scanFolder(uri));
            } catch (Exception ex) { status("폴더 연결 실패: " + ex.getMessage()); }
        } else if (request == PICK_ARCHIVE) {
            ArrayList<Uri> uris = new ArrayList<>();
            if (data.getData() != null) uris.add(data.getData());
            ClipData clip = data.getClipData();
            if (clip != null) for (int i=0; i<clip.getItemCount(); i++) uris.add(clip.getItemAt(i).getUri());
            SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
            Set<String> remembered = new HashSet<>(prefs.getStringSet("archives", Collections.emptySet()));
            for (Uri uri : uris) {
                try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); remembered.add(uri.toString()); }
                catch (Exception ignored) { /* some providers do not support persisting */ }
                executor.execute(() -> indexUri(uri, false));
            }
            prefs.edit().putStringSet("archives", remembered).apply();
        } else if (request == SAVE_EXPORT && pendingExport != null) {
            try (InputStream input = new FileInputStream(pendingExport); OutputStream output = getContentResolver().openOutputStream(data.getData())) {
                if (output == null) throw new Exception("쓰기 권한이 없습니다.");
                byte[] buffer = new byte[65536]; int n;
                while ((n = input.read(buffer)) != -1) output.write(buffer, 0, n);
                toast("파일이 저장됐습니다.");
            } catch (Exception ex) { toast("저장 실패: " + ex.getMessage()); }
            pendingExport = null;
        }
    }

    private static final class PendingDir {
        final Uri uri; final int depth;
        PendingDir(Uri u, int d){uri=u;depth=d;}
    }
    private void scanFolder(Uri tree) {
        final int current = ++generation;
        status("선택한 마인크래프트 폴더 검색 중…");
        try {
            ArrayDeque<PendingDir> q = new ArrayDeque<>();
            q.add(new PendingDir(tree, 0));
            int filesSeen=0, archives=0;
            while (!q.isEmpty() && filesSeen<MAX_FILES && archives<MAX_ARCHIVES && current==generation) {
                PendingDir p=q.removeFirst();
                if(p.depth>8) continue;
                Uri docUri = p.depth==0 ? tree : p.uri;
                String docId = p.depth==0 ? DocumentsContract.getTreeDocumentId(tree) : DocumentsContract.getDocumentId(docUri);
                Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
                String[] projection = {DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE};
                try(Cursor cur = getContentResolver().query(children, projection, null, null, null)) {
                    if(cur == null) continue;
                    while(cur.moveToNext() && filesSeen++<MAX_FILES) {
                        String childId=cur.getString(0), name=cur.getString(1), mime=cur.getString(2);
                        if(name==null) continue;
                        Uri child=DocumentsContract.buildDocumentUriUsingTree(tree, childId);
                        if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                            if(p.depth<8 && (!name.startsWith(".") || ".minecraft".equals(name))) q.addLast(new PendingDir(child,p.depth+1));
                        } else if(archiveName(name) && archives++<MAX_ARCHIVES) {
                            indexUri(child,true);
                        }
                    }
                } catch (Exception ignored) { /* a provider may hide some subfolders */ }
            }
            status("폴더 검색 완료 · 원본 게임, 모드, 리소스팩 색인됨");
        } catch(Exception ex) {status("폴더 검색 제한: "+ex.getMessage()+" · 개별 JAR·ZIP 선택을 이용하세요.");}
    }
    private static boolean archiveName(String name){
        String n=name.toLowerCase(Locale.ROOT);
        return n.endsWith(".jar") || n.endsWith(".zip");
    }
    private String displayName(Uri uri) {
        try(Cursor c=getContentResolver().query(uri,new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME},null,null,null)){
            if(c!=null && c.moveToFirst())return c.getString(0);
        }catch(Exception ignored){}
        return uri.getLastPathSegment();
    }
    private void indexUri(Uri uri, boolean quiet) {
        try {
            String name=displayName(uri);
            if(name==null || !archiveName(name)) return;
            String safeKey=Integer.toHexString(uri.toString().hashCode());
            File local=new File(getCacheDir(),"mc-archive-"+safeKey);
            if(!local.exists() || local.length()==0){
                File tmp=new File(getCacheDir(),"tmp-"+safeKey);
                try(InputStream input=getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(tmp)){
                    if(input==null)throw new Exception("파일을 열 수 없습니다.");
                    byte[] buf=new byte[65536]; int n;long total=0;
                    while((n=input.read(buf))!=-1){total+=n;if(total>MAX_ARCHIVE_SIZE)throw new Exception("파일 크기 제한 370MB 초과");out.write(buf,0,n);}
                }
                if(!tmp.renameTo(local)) throw new Exception("임시 파일 처리 실패");
            }
            Source source=new Source();source.id="src"+safeKey;source.title=name;source.archive=local;
            List<Texture> pending=new ArrayList<>();
            try(ZipFile zip=new ZipFile(local)){
                java.util.Enumeration<? extends ZipEntry> e=zip.entries();
                while(e.hasMoreElements()){
                    ZipEntry ent=e.nextElement();
                    String path=ent.getName();
                    if(ent.isDirectory()|| !path.endsWith(".png")||!path.startsWith("assets/")||!path.contains("/textures/")||ent.getSize()>MAX_TEXTURE_SIZE)continue;
                    source.paths.add(path);
                    Texture tex=new Texture();tex.archive=local;tex.path=path;pending.add(tex);
                }
            }
            synchronized(catalogLock){
                boolean exists=false;
                for(Source old:sources) if(old.id.equals(source.id)) {exists=true;break;}
                if(!exists && !pending.isEmpty()) {sources.add(source);textures.addAll(pending);}
            }
            status("자료 연결: "+source.title+" · 이미지 "+source.paths.size()+"개");
            inject("window.MathCraftAndroidLibrary&&window.MathCraftAndroidLibrary.onLibraryChanged();");
        }catch(Exception e){if(!quiet)status("압축 파일 가져오기 실패: "+e.getMessage());}
    }
    private JSONObject sourceJson(Source s) throws Exception {
        JSONObject j=new JSONObject(); j.put("id",s.id);j.put("title",s.title);j.put("count",s.paths.size());return j;
    }

    private final class Bridge {
        @JavascriptInterface public void chooseGameFolder(){main.post(MainActivity.this::openFolder);}
        @JavascriptInterface public void chooseArchiveFiles(){main.post(MainActivity.this::openArchives);}
        @JavascriptInterface public void refresh(){executor.execute(()->{if(chosenTree!=null)scanFolder(chosenTree);});}
        @JavascriptInterface public String listSources(){
            JSONArray a=new JSONArray();synchronized(catalogLock){for(Source s:sources){try{a.put(sourceJson(s));}catch(Exception ignored){}}}
            return a.toString();
        }
        @JavascriptInterface public String listPaths(String id){
            JSONArray a=new JSONArray();synchronized(catalogLock){for(Source s:sources)if(s.id.equals(id)){for(String path:s.paths)a.put(path);break;}}
            return a.toString();
        }
        @JavascriptInterface public String textureBase64(String id, String path){
            File file=null;
            synchronized(catalogLock){for(Source s:sources) if(s.id.equals(id)&&s.paths.contains(path)){file=s.archive;break;}}
            if(file==null)return "";
            try(ZipFile zip=new ZipFile(file)) {
                ZipEntry entry=zip.getEntry(path);
                if(entry==null||entry.getSize()>MAX_TEXTURE_SIZE)return "";
                try(InputStream in=zip.getInputStream(entry);ByteArrayOutputStream out=new ByteArrayOutputStream()){
                    byte[] b=new byte[32768];int n;
                    while((n=in.read(b))!=-1){if(out.size()+n>MAX_TEXTURE_SIZE)return "";out.write(b,0,n);}
                    return Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP);
                }
            }catch(Exception e){return "";}
        }
        @JavascriptInterface public String beginExport(String filename){
            String id=UUID.randomUUID().toString();
            try {
                File output=new File(getCacheDir(),"export-"+id);
                if(!output.createNewFile())return "";
                synchronized(exports){exports.put(id,output);}
                return id;
            }catch(Exception e){return "";}
        }
        @JavascriptInterface public boolean exportChunk(String id,String b64){
            File f;synchronized(exports){f=exports.get(id);}
            if(f==null||f.length()>250L*1024*1024)return false;
            try(FileOutputStream out=new FileOutputStream(f,true)){
                out.write(Base64.decode(b64,Base64.DEFAULT));return true;
            }catch(Exception e){return false;}
        }
        @JavascriptInterface public void finishExport(String id, String filename, String mime){
            File f;synchronized(exports){f=exports.remove(id);}
            if(f==null)return;
            main.post(()->{
                pendingExport=f;
                Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(mime==null||mime.isEmpty()?"application/zip":mime);
                intent.putExtra(Intent.EXTRA_TITLE,filename==null||filename.trim().isEmpty()?"수학세계_프로젝트.zip":filename);
                startActivityForResult(intent,SAVE_EXPORT);
            });
        }
        @JavascriptInterface public void notifyUser(String text){toast(text);}
    }

    @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
    @Override public void onDestroy(){executor.shutdownNow();web.destroy();super.onDestroy();}
}
