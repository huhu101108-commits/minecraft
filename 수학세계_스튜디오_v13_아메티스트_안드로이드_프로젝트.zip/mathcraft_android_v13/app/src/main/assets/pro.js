'use strict';
/* v11 workspace improvements: retains v10 Fabric source generation and math engines. */
const V11_PREF_KEY = 'mathcraft_studio_v11_preferences';
const v11Prefs = (()=>{ try{return JSON.parse(localStorage.getItem(V11_PREF_KEY))||{};}catch{return {};} })();
let v11Multi=false;
let v11Selected=new Set();
let v11MultiDrag=null;
let v11Zoom=v11Prefs.zoom||'fit';
let v11Grid=!!v11Prefs.grid;
let v11Guides=v11Prefs.guides!==false;
function saveV11Prefs(){try{localStorage.setItem(V11_PREF_KEY,JSON.stringify({zoom:v11Zoom,grid:v11Grid,guides:v11Guides}));}catch{}}
function v11Element(key){
  const m=machine();
  if(key.startsWith('img:'))return (m.layers||[]).find(x=>'img:'+x.id===key);
  if(key.startsWith('txt:'))return (m.decoration||[]).find(x=>'txt:'+x.id===key);
  return m.elements[key];
}
function v11Keys(){
  const m=machine();return [
    ...Object.keys(m.elements).filter(k=>k!=='toggle'||def().modes.length>1),
    ...(m.layers||[]).map(x=>'img:'+x.id),
    ...(m.decoration||[]).map(x=>'txt:'+x.id)
  ];
}
function v11SyncList(){
 const keys=v11Keys();const items=[...$('elementList').children];
 items.forEach((el,i)=>{el.dataset.key=keys[i]||'';el.classList.toggle('multi-selected',v11Selected.has(keys[i]));el.title=(keys[i]||'')+' · 누르면 선택';});
 $('bulkMode').classList.toggle('active',v11Multi);
 $('bulkMode').textContent=v11Multi?'선택 끝내기':'다중 선택';
 $('bulkStatus').textContent=v11Selected.size>1?`${v11Selected.size}개 요소 선택 · 드래그/화살표로 함께 이동 가능`:v11Multi?'레이어 이름을 눌러 여러 개 선택하세요':'요소를 여러 개 고르면 함께 정렬할 수 있어요';
 const isImg=chosen.startsWith('img:');
 $('layerVisibility').style.display=isImg?'block':'none';$('layerLock').style.display=isImg?'block':'none';
 if(isImg){const l=v11Element(chosen);$('layerVisibility').textContent=l?.hidden?'이미지 보이기':'이미지 숨기기';$('layerLock').textContent=l?.locked?'드래그 잠금 해제':'드래그 잠금';}
 $('miniStats').textContent=`작업대 ${MACHINES.length}개 · 현재 요소 ${keys.length}개`;
 if(document.activeElement!==$('projectName'))$('projectName').value=doc.title||'나의 수학세계';
}
const v11OldRefresh=refresh;
refresh=function(){v11OldRefresh();if(!v11Multi)v11Selected=new Set([chosen]);v11Selected=new Set([...v11Selected].filter(k=>v11Element(k)));v11SyncList();};
$('elementList').addEventListener('click',e=>{
 const button=e.target.closest('button[data-key]');if(!button)return;
 if(!(v11Multi||e.ctrlKey||e.metaKey||e.shiftKey)){v11Selected=new Set([button.dataset.key]);return;}
 e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();
 const key=button.dataset.key;
 if(v11Selected.has(key))v11Selected.delete(key);else v11Selected.add(key);
 if(v11Selected.size===1){chosen=[...v11Selected][0];}
 v11SyncList();draw();
},true);
$('bulkMode').onclick=()=>{v11Multi=!v11Multi;if(!v11Multi)v11Selected=new Set([chosen]);v11SyncList();draw();};
function v11Align(type){
 const picked=[...v11Selected].map(k=>[k,v11Element(k)]).filter(([k,e])=>e&&(!k.startsWith('img:')||!e.locked));
 if(picked.length<2)return tip('정렬할 요소를 두 개 이상 선택해 주세요.');
 hist();
 if(type==='x'){let x=Math.min(...picked.map(([k,e])=>e.x));picked.forEach(([k,e])=>doMove(e,x,e.y));}
 if(type==='y'){let y=Math.min(...picked.map(([k,e])=>e.y));picked.forEach(([k,e])=>doMove(e,e.x,y));}
 if(type==='space'){
   const sort=picked.sort((a,b)=>a[1].x-b[1].x);const first=sort[0][1],last=sort[sort.length-1][1];
   const maxStart=last.x;const start=first.x;const step=(maxStart-start)/(sort.length-1);
   sort.forEach(([k,e],i)=>doMove(e,Math.round(start+step*i),e.y));
 }
 changed();tip(type==='space'?'간격을 균등하게 배치했습니다.':'선택한 요소를 정렬했습니다.');
}
$('bulkAlignX').onclick=()=>v11Align('x');$('bulkAlignY').onclick=()=>v11Align('y');$('bulkDistribute').onclick=()=>v11Align('space');

// The original Fabric layout and exported PNGs remain separate from visual-only grids.
const v11OldDrawEditor=drawEditor;
drawEditor=function(canvas,editable=true){
 v11OldDrawEditor(canvas,editable);
 if(canvas.id!=='editor'||!editable)return;
 const ctx=canvas.getContext('2d');ctx.save();ctx.scale(canvas.width/176,canvas.height/166);ctx.imageSmoothingEnabled=false;
 if(v11Grid){ctx.beginPath();for(let x=8;x<176;x+=8){ctx.moveTo(x+.5,0);ctx.lineTo(x+.5,166);}for(let y=8;y<166;y+=8){ctx.moveTo(0,y+.5);ctx.lineTo(176,y+.5);}ctx.strokeStyle='rgba(31,112,108,.18)';ctx.lineWidth=.28;ctx.stroke();}
 if(v11Guides){ctx.setLineDash([2,3]);ctx.strokeStyle='rgba(34,110,113,.45)';ctx.lineWidth=.3;ctx.beginPath();ctx.moveTo(88,0);ctx.lineTo(88,166);ctx.moveTo(0,83);ctx.lineTo(176,83);ctx.stroke();ctx.setLineDash([]);}
 if(v11Selected.size>1){for(const key of v11Selected){const el=v11Element(key);if(!el)continue;ctx.strokeStyle='#0b9475';ctx.lineWidth=.85;ctx.strokeRect(el.x-1,el.y-1,el.w+2,el.h+2);}}
 ctx.restore();
};
$('showGrid').checked=v11Grid;$('showGuides').checked=v11Guides;
$('showGrid').onchange=e=>{v11Grid=e.target.checked;saveV11Prefs();draw();};
$('showGuides').onchange=e=>{v11Guides=e.target.checked;saveV11Prefs();draw();};
function v11ApplyZoom(){
 const stage=$('workspaceStage'),canvas=$('editor');
 const width=v11Zoom==='fit'?Math.min(528,Math.max(155,stage.clientWidth-35)):528*Number(v11Zoom)/100;
 canvas.style.width=Math.round(width)+'px';canvas.style.height=Math.round(width*498/528)+'px';
 $('zoomValue').value=v11Zoom;saveV11Prefs();
}
$('zoomValue').onchange=e=>{v11Zoom=e.target.value;v11ApplyZoom();};
for(const [id,step] of [['zoomIn',1],['zoomOut',-1]])$(id).onclick=()=>{
 const choices=[75,100,125,150,200];const current=v11Zoom==='fit'?100:Number(v11Zoom);const i=choices.indexOf(current);
 v11Zoom=String(choices[Math.max(0,Math.min(choices.length-1,(i<0?1:i)+step))]);v11ApplyZoom();
};
if(typeof ResizeObserver!=='undefined')new ResizeObserver(()=>{if(v11Zoom==='fit')v11ApplyZoom();}).observe($('workspaceStage'));
requestAnimationFrame(v11ApplyZoom);

// Dragging an already multi-selected component moves the whole selection.
$('editor').addEventListener('pointerdown',e=>{
 const p=coordinate(e,$('editor'),176,166),m=machine();
 const arr=[...Object.entries(m.elements),...(m.decoration||[]).map(x=>['txt:'+x.id,x]),...(m.layers||[]).filter(x=>!x.hidden).map(x=>['img:'+x.id,x])].reverse();
 const hit=arr.find(([key,el])=>(key!=='toggle'||def().modes.length>1)&&p.x>=el.x&&p.x<=el.x+(el.w||55)&&p.y>=el.y&&p.y<=el.y+(el.h||12));
 if(!hit||!v11Multi||!v11Selected.has(hit[0])||v11Selected.size<2){v11MultiDrag=null;return;}
 v11MultiDrag={key:hit[0],positions:new Map([...v11Selected].map(key=>{const el=v11Element(key);return [key,el?{x:el.x,y:el.y}:null];}))};
},true);
$('editor').addEventListener('pointermove',e=>{
 if(!drag||!v11MultiDrag||drag.id!==e.pointerId||chosen!==v11MultiDrag.key)return;
 const primary=v11Element(chosen),before=v11MultiDrag.positions.get(chosen);if(!primary||!before)return;
 const dx=primary.x-before.x,dy=primary.y-before.y;
 for(const [key,pos] of v11MultiDrag.positions){if(key===chosen||!pos)continue;const el=v11Element(key);if(el&&!el.locked)doMove(el,pos.x+dx,pos.y+dy);}
 draw();
});
for(const type of ['pointerup','pointercancel'])$('editor').addEventListener(type,()=>{v11MultiDrag=null;});
$('layerVisibility').onclick=()=>{if(!chosen.startsWith('img:'))return;hist();const l=v11Element(chosen);l.hidden=!l.hidden;changed();};
$('layerLock').onclick=()=>{if(!chosen.startsWith('img:'))return;hist();const l=v11Element(chosen);l.locked=!l.locked;changed();};

const v11Presets={
 classic:{inputA:[27,35],inputB:[76,35],output:[134,35],run:[103,63],toggle:[44,63]},
 wide:{inputA:[16,39],inputB:[54,39],output:[137,39],run:[91,65],toggle:[33,65]},
 compact:{inputA:[15,25],inputB:[15,48],output:[141,37],run:[95,78],toggle:[34,78]}
};
$('applyPreset').onclick=()=>{
 const key=$('layoutPreset').value;if(!v11Presets[key])return tip('배치 유형을 먼저 선택해 주세요.');
 if(!confirm('기본 입력·출력 슬롯 및 버튼 위치를 변경할까요? 추가한 슬롯과 이미지는 유지됩니다.'))return;
 hist();for(const [k,position] of Object.entries(v11Presets[key])){const el=machine().elements[k];if(el){el.x=position[0];el.y=position[1];}}
 changed();tip('선택한 배치를 적용했어요.');
};

// Local-only drag-and-drop: PNG layer, archive import, project recovery.
$('workspaceStage').addEventListener('dragover',e=>{e.preventDefault();e.dataTransfer.dropEffect='copy';$('workspaceStage').classList.add('drag-over');});
$('workspaceStage').addEventListener('dragleave',()=>$('workspaceStage').classList.remove('drag-over'));
$('workspaceStage').addEventListener('drop',async e=>{
 e.preventDefault();$('workspaceStage').classList.remove('drag-over');const file=e.dataTransfer?.files?.[0];if(!file)return;
 if(!/\.png$/i.test(file.name)){tip('이 영역에는 PNG 이미지만 놓을 수 있어요.');return;}
 try{hist();const src=await toData(file),id='drop_'+Date.now().toString(36);ensureV10(machine()).layers.push({id,src,label:file.name,x:50,y:40,w:48,h:48,scale:100,angle:0,opacity:1});chosen='img:'+id;changed();tip('이미지 레이어를 추가했습니다.');}catch(ex){tip('이미지 가져오기 실패: '+ex.message);}
});

// Project identity persists in JSON exports and autosave.
doc.title=doc.title||'나의 수학세계';$('projectName').value=doc.title;
$('projectName').addEventListener('change',e=>{doc.title=String(e.target.value||'나의 수학세계').trim().slice(0,48);saveSoon();});
$('projectSave').onclick=()=>{doc.title=$('projectName').value.trim()||'나의 수학세계';download(JSON.stringify(doc,null,2),(doc.title.replace(/[\\/:*?"<>|]/g,'_'))+'_프로젝트.json','application/json');};

function v11OpenDialog(title,html){$('studioDialogTitle').textContent=title;$('studioDialogContent').innerHTML=html;$('studioDialog').classList.remove('hidden');}
function v11CloseDialogs(){$('commandPalette').classList.add('hidden');$('studioDialog').classList.add('hidden');}
$('studioDialogClose').onclick=v11CloseDialogs;
$('studioDialog').onclick=e=>{if(e.target===$('studioDialog'))v11CloseDialogs();};
const v11Help=`<p>작업대 화면의 슬롯, 이미지, 버튼을 옮기면 Fabric 모드 소스의 배치에 반영됩니다. 데이터팩만으로 기본 슬롯 좌표를 바꿀 수는 없습니다.</p><h4>주요 단축키</h4><table><tr><td><code>Ctrl + K</code></td><td>빠른 찾기 열기</td></tr><tr><td><code>Ctrl + S</code></td><td>프로젝트 JSON 저장</td></tr><tr><td><code>Ctrl + O</code></td><td>프로젝트 파일 불러오기</td></tr><tr><td><code>Ctrl + Z / Y</code></td><td>실행 취소 / 다시 실행</td></tr><tr><td><code>Ctrl + D</code></td><td>선택 요소 복제</td></tr><tr><td><code>방향키</code></td><td>선택 요소 1픽셀 이동</td></tr><tr><td><code>Shift + 방향키</code></td><td>선택 요소 8픽셀 이동</td></tr><tr><td><code>Delete</code></td><td>추가 요소 삭제</td></tr><tr><td><code>Esc</code></td><td>팝업 닫기</td></tr></table><h4>빠른 제작</h4><ul><li>PNG를 편집 영역에 끌어 놓으면 이미지 레이어가 추가됩니다.</li><li>레이어 목록의 다중 선택을 켜면 함께 이동·정렬할 수 있습니다.</li><li>확대해 놓고 편집한 뒤 100% 또는 화면 맞춤으로 확인하세요.</li><li>원본 JAR·ZIP을 불러와 마인크래프트 텍스처를 활용할 수 있습니다.</li><li>배포 전 배치 검사를 실행하고, 프로젝트 파일을 따로 백업하세요.</li></ul><div class="notice"><b>출력 구분</b><p>리소스팩은 그래픽, 데이터팩은 명령 기반 기능, Fabric 모드 소스는 실제 슬롯 UI와 아이템 처리를 담당합니다. 제작된 Java 소스의 빌드 및 게임 실행 검증은 별도로 필요합니다.</p></div>`;
$('helpOpen').onclick=()=>v11OpenDialog('사용법과 단축키',v11Help);
$('sidebarGuide').onclick=()=>v11OpenDialog('사용법과 단축키',v11Help);

function v11Diagnostics(){
 const issues=[];
 for(const m of MACHINES){
  const mm=doc.machines[m.id],entries=Object.entries(mm.elements||{}),slots=entries.filter(([,e])=>e.type==='slot'||e.type==='output');
  for(const [key,el] of entries){
   if(!Number.isFinite(el.x)||!Number.isFinite(el.y)||el.x<0||el.y<0||el.x+el.w>176||el.y+el.h>166)issues.push({machine:m.id,message:`${m.name}: ${el.label||key}이(가) 화면 경계를 벗어났습니다.`});
   if((el.type==='slot'||el.type==='output')&&(el.w!==18||el.h!==18))issues.push({machine:m.id,message:`${m.name}: 실제 슬롯 크기는 18×18입니다.`});
  }
  for(let i=0;i<slots.length;i++)for(let j=i+1;j<slots.length;j++){
   const a=slots[i][1],b=slots[j][1];if(Math.abs(a.x-b.x)<16&&Math.abs(a.y-b.y)<16){issues.push({machine:m.id,message:`${m.name}: ${a.label}과(와) ${b.label} 슬롯이 겹칩니다.`});}
  }
  const extra=entries.filter(([k])=>k.startsWith('extra_'));
  if(extra.length>24)issues.push({machine:m.id,message:`${m.name}: 추가 슬롯이 24개를 초과합니다.`});
 }
 return issues;
}
function v11ShowDiagnostics(){
 const issues=v11Diagnostics();const total=MACHINES.reduce((v,m)=>v+Object.keys(doc.machines[m.id].elements).length,0);
 let html=`<p>전체 <b>${MACHINES.length}개 작업대</b>, <b>${total}개 화면 요소</b>를 검사했습니다.</p>`;
 if(!issues.length)html+='<p class="ok">배치 충돌과 화면 밖 요소가 발견되지 않았습니다.</p>';
 else html+=`<p>수정할 항목 <b>${issues.length}개</b></p>`+issues.slice(0,40).map(issue=>`<div class="issue"><span>${escapeHtml(issue.message)}</span><button data-machine="${issue.machine}">화면 열기</button></div>`).join('');
 html+='<div class="notice">이 검사는 화면 좌표와 요소의 기본 구조를 확인합니다. Java 컴파일·아메티스트의 실제 게임 동작을 보증하지 않습니다.</div>';
 v11OpenDialog('프로젝트 검사',html);
 $('studioDialogContent').querySelectorAll('[data-machine]').forEach(b=>b.onclick=()=>{doc.selected=b.dataset.machine;chosen='inputA';selectPanel('layout');refresh();v11CloseDialogs();});
}
$('diagnoseTop').onclick=v11ShowDiagnostics;$('diagnoseExport').onclick=v11ShowDiagnostics;

const commandActions=[
 ...MACHINES.map(m=>({label:m.name,hint:'작업대 열기',run:()=>{doc.selected=m.id;chosen='inputA';v11Selected=new Set([chosen]);selectPanel('layout');refresh();}})),
 ...[['화면 편집','layout'],['동작 설정','logic'],['원본 텍스처','textures'],['내보내기','export']].map(([label,tab])=>({label,hint:'메뉴',run:()=>selectPanel(tab)})),
 {label:'프로젝트 검사',hint:'문제 확인',run:v11ShowDiagnostics},
 {label:'프로젝트 백업 저장',hint:'JSON 다운로드',run:()=>$('projectSave').click()},
 {label:'이미지 레이어 추가',hint:'PNG 가져오기',run:()=>{$('addLayer').click();}},
 {label:'Fabric 모드 소스 생성',hint:'ZIP 다운로드',run:()=>{$('exportMod').click();}},
];
function v11RenderCommands(){const q=$('commandInput').value.trim().toLowerCase();$('commandResults').innerHTML='';const matches=commandActions.filter(a=>a.label.toLowerCase().includes(q)||a.hint.toLowerCase().includes(q));for(const a of matches.slice(0,18)){
 const b=document.createElement('button');b.innerHTML=`<span>${escapeHtml(a.label)}</span><small>${escapeHtml(a.hint)}</small>`;
 b.onclick=()=>{v11CloseDialogs();a.run();};$('commandResults').append(b);
 }if(!matches.length)$('commandResults').textContent='찾는 항목이 없습니다.';
}
function v11OpenCommand(){$('commandPalette').classList.remove('hidden');$('commandInput').value='';v11RenderCommands();$('commandInput').focus();}
$('commandOpen').onclick=v11OpenCommand;$('commandInput').oninput=v11RenderCommands;
$('commandPalette').onclick=e=>{if(e.target===$('commandPalette'))v11CloseDialogs();};
$('commandInput').addEventListener('keydown',e=>{if(e.key==='Enter'){$('commandResults').querySelector('button')?.click();e.preventDefault();}});

window.addEventListener('keydown',e=>{
 const ctrl=e.ctrlKey||e.metaKey;
 if(e.key==='Escape'){v11CloseDialogs();return;}
 if(ctrl&&e.key.toLowerCase()==='k'){e.preventDefault();v11OpenCommand();return;}
 if(ctrl&&e.key.toLowerCase()==='s'){e.preventDefault();$('projectSave').click();return;}
 if(ctrl&&e.key.toLowerCase()==='o'){e.preventDefault();$('projectLoad').click();return;}
 const typing=e.target instanceof HTMLElement&&/INPUT|TEXTAREA|SELECT/.test(e.target.tagName);
 if(typing||!$('commandPalette').classList.contains('hidden')||!$('studioDialog').classList.contains('hidden'))return;
 if(ctrl&&e.key.toLowerCase()==='z'){e.preventDefault();undo();return;}
 if(ctrl&&(e.key.toLowerCase()==='y'||(e.shiftKey&&e.key.toLowerCase()==='z'))){e.preventDefault();redo();return;}
 if(ctrl&&e.key.toLowerCase()==='d'){e.preventDefault();$('duplicateElement').click();return;}
 if(e.key==='Delete'||e.key==='Backspace'){e.preventDefault();$('removeElement').click();return;}
 if(document.activeElement===$('editor'))return; // existing editor key handler
 const move={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[e.key];
 if(move&&panel==='layout'){
   e.preventDefault();const keys=v11Multi&&v11Selected.size>1?[...v11Selected]:[chosen];hist();
   for(const key of keys){const el=v11Element(key);if(el&&!el.locked)doMove(el,el.x+move[0]*(e.shiftKey?8:1),el.y+move[1]*(e.shiftKey?8:1));}
   changed();
 }
});
refresh();
window.MC_PRO_TEST={diagnostics:v11Diagnostics,zoom:()=>v11Zoom,selected:()=>[...v11Selected],setProjectName:s=>{doc.title=s;refresh();saveSoon();},getDoc:()=>doc};
// Browsable categories for vanilla resource archives; the original paths stay unchanged.
let v11TextureKind='all';
const v11BaseRenderGallery=renderGallery;
renderGallery=function(){
 const originalPaths=paths;
 if(v11TextureKind!=='all'){
   paths=originalPaths.filter(p=>{
     if(v11TextureKind==='block')return p.includes('/textures/block/');
     if(v11TextureKind==='item')return p.includes('/textures/item/');
     return p.includes('/textures/gui/')||p.includes('/textures/gui/sprites/');
   });
 }
 try{v11BaseRenderGallery();}finally{paths=originalPaths;}
};
for(const b of document.querySelectorAll('[data-texture-kind]'))b.onclick=()=>{
 v11TextureKind=b.dataset.textureKind;
 for(const item of document.querySelectorAll('[data-texture-kind]'))item.classList.toggle('active',item===b);
 renderGallery();
};
