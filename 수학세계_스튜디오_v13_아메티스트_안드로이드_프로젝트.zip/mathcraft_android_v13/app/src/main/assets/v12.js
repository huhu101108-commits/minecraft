'use strict';
/* v12 Minecraft textures: explicit local access only; no uploads, no tracking. */
const v12={sources:[],selected:'all',kind:'all',limit:120,sort:'name',filter:'',active:null,token:new URLSearchParams(location.search).get('token')||'',folderHandle:null,blobCache:new Map(),observer:null,generation:0,db:null,loading:false};
const V12_MAX_ARCHIVE=320*1024*1024, V12_MAX_TEXTURE=18*1024*1024;
const V12_ALIAS={ '돌':['stone','cobblestone','deepslate'],'흙':['dirt','mud'],'잔디':['grass'],'나무':['oak','planks','log'],'원목':['log','wood'],'다이아':['diamond'],'철':['iron'],'금':['gold'],'구리':['copper'],'흑요석':['obsidian'],'네더':['nether'],'엔더':['end','ender'],'자수정':['amethyst'],'작업대':['crafting_table'],'상자':['chest'],'인벤토리':['inventory'],'버튼':['button'],'핫바':['hotbar'],'방어구':['armor'],'검':['sword'],'활':['bow'],'포탈':['portal'],'문':['door'],'물':['water'],'용암':['lava'],'보라':['purple'],'스티브':['steve'],'눈':['snow']};
function v12Status(message,ready=false){$('v12LibraryStatus').textContent=message;$('libraryConnection').textContent=ready?'연결됨':'로컬 자료';$('libraryConnection').classList.toggle('ready',ready);}
function v12ValidName(n){return /^(assets\/[a-z0-9_.-]+\/(textures|gui)\/.*\.png|textures\/.*\.png)$/i.test(n) && !n.includes('..');}
function v12Kind(path){let p=path.toLowerCase();if(p.includes('/block/'))return 'block';if(p.includes('/item/'))return 'item';if(p.includes('/gui/')||p.includes('/container/')||p.includes('/hud/'))return 'gui';if(p.includes('/entity/')||p.includes('/models/armor/'))return 'entity';if(p.includes('/particle/')||p.includes('/effect/'))return 'particle';return 'other';}
function v12SourceTitle(s){return `${s.title} · ${s.count||s.paths?.length||0}장`}
function v12AddSource(source){let old=v12.sources.findIndex(s=>s.id===source.id);if(old>=0)v12.sources[old]=source;else v12.sources.push(source);v12UpdateSources();}
function v12UpdateSources(){let q=$('v12Source');let prev=v12.selected;q.innerHTML='';let all=document.createElement('option');all.value='all';all.textContent='모든 연결 자료';q.appendChild(all);for(let s of v12.sources){let opt=document.createElement('option');opt.value=s.id;opt.textContent=v12SourceTitle(s);q.appendChild(opt)};v12.selected=v12.sources.some(s=>s.id===prev)?prev:'all';q.value=v12.selected;v12SetPaths();let n=v12.sources.reduce((a,s)=>a+s.paths.length,0);v12Status(v12.sources.length?`${v12.sources.length}개 자료에서 PNG ${n.toLocaleString('ko-KR')}개를 찾았어요. 자료를 선택하거나 이름으로 검색하세요. (원본 파일은 변경하지 않습니다.)`:'자료가 없습니다. PC 도우미를 실행하거나 태블릿에서 폴더 접근을 허용해 주세요.',v12.sources.length>0)}
function v12SetPaths(){let pool=v12.selected==='all'?v12.sources:v12.sources.filter(x=>x.id===v12.selected);let indexed=new Map();for(let s of pool)for(let p of s.paths)if(!indexed.has(p))indexed.set(p,s);v12.active=indexed;paths=[...indexed.keys()];if(v12.sort==='name')paths.sort((a,b)=>a.split('/').at(-1).localeCompare(b.split('/').at(-1)));else paths.sort();v12.limit=120;v12RenderGallery();}
function v12BlobToData(blob){return new Promise((resolve,reject)=>{let reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(reader.error);reader.readAsDataURL(blob);});}
async function v12BlobFor(p){const key=(v12.active?.get(p)?.id||'')+'|'+p;if(v12.blobCache.has(key)){let v=v12.blobCache.get(key);v12.blobCache.delete(key);v12.blobCache.set(key,v);return v;}let s=v12.active?.get(p);if(!s)return null;let blob=await s.get(p);if(!blob||blob.size>V12_MAX_TEXTURE)return null;v12.blobCache.set(key,blob);if(v12.blobCache.size>160)v12.blobCache.delete(v12.blobCache.keys().next().value);return blob;}
vanillaImage=async function(p){let blob=await v12BlobFor(p);return blob? v12BlobToData(blob):'';};
function v12QueryMatches(path,q){if(!q)return true;let clean=path.toLowerCase(),words=q.toLowerCase().split(/\s+/).filter(Boolean);return words.every(word=>clean.includes(word)||(V12_ALIAS[word]||[]).some(alias=>clean.includes(alias)));}
function v12RenderGallery(){
 const g=$('textureGallery');if(!g)return;
 let q=$('textureSearch').value.toLowerCase().trim();const req=v12.kind;let filtered=paths.filter(p=>(req==='all'||v12Kind(p)===req)&&v12QueryMatches(p,q));let count=filtered.length;let shown=filtered.slice(0,v12.limit),gen=++v12.generation;
 g.innerHTML='';$('v12ResultCount').textContent=`검색 결과 ${count.toLocaleString('ko-KR')}개 · 현재 ${shown.length.toLocaleString('ko-KR')}개 표시`;
 $('v12More').hidden=shown.length>=count;
 if(!shown.length){let d=document.createElement('div');d.className='library-empty';d.textContent=paths.length?'일치하는 이미지가 없습니다. 검색어 또는 분류를 바꿔 보세요.':'이미지 자료를 연결하면 블록·아이템·GUI 등을 검색할 수 있어요.';g.appendChild(d);return;}
 if(v12.observer)v12.observer.disconnect();v12.observer=typeof IntersectionObserver!=='undefined'?new IntersectionObserver(entries=>{for(const it of entries)if(it.isIntersecting){v12.observer.unobserve(it.target);v12LoadThumb(it.target,gen);}}, {root:g,rootMargin:'150px'}):null;
 for(const path of shown){let s=v12.active.get(path),b=document.createElement('button');b.type='button';b.dataset.path=path;b.className=path===activeOriginal?'selected':'';
 let ph=document.createElement('div');ph.className='placeholder';ph.textContent='PNG';b.appendChild(ph);
 let t=document.createElement('span');t.textContent=path.split('/').pop().replace(/\.png$/,'');t.title=path;b.appendChild(t);
 let meta=document.createElement('small');meta.className='source-pill';meta.textContent=s.title;meta.title=s.title;b.appendChild(meta);
 b.onclick=async()=>{try{tip('이미지 불러오는 중…');let blob=await v12BlobFor(path);if(!blob)throw new Error('PNG를 읽지 못했습니다.');hist();activeOriginal=path;if(!doc.overrides[path])doc.overrides[path]={base:await v12BlobToData(blob),overlay:null};originalOverlay=doc.overrides[path].overlay;refreshOriginal();renderGallery();saveSoon();tip('원본 텍스처를 선택했어요.');}catch(e){tip('이미지 불러오기 실패: '+e.message)}};
 g.appendChild(b);if(v12.observer)v12.observer.observe(b);else v12LoadThumb(b,gen);
 }
}
async function v12LoadThumb(b,gen){const p=b.dataset.path;try{let blob=await v12BlobFor(p);if(!blob||gen!==v12.generation||!b.isConnected)return;let u=URL.createObjectURL(blob);let image=new Image();image.className='thumb';image.alt=p.split('/').at(-1);image.loading='lazy';image.onload=()=>URL.revokeObjectURL(u);image.onerror=()=>URL.revokeObjectURL(u);image.src=u;b.querySelector('.placeholder')?.replaceWith(image);}catch{}}
renderGallery=v12RenderGallery;
$('textureSearch').oninput=()=>{v12.limit=120;v12RenderGallery();};
for(let b of document.querySelectorAll('[data-texture-kind]'))b.onclick=()=>{v12.kind=b.dataset.textureKind;for(let other of document.querySelectorAll('[data-texture-kind]'))other.classList.toggle('active',other===b);v12.limit=120;v12RenderGallery();};
$('v12More').onclick=()=>{v12.limit+=120;v12RenderGallery();};
$('v12Source').onchange=e=>{v12.selected=e.target.value;v12SetPaths();};
$('v12Sort').onchange=e=>{v12.sort=e.target.value;v12SetPaths();};
async function v12ImportZip(file,id){
 if(file.size>V12_MAX_ARCHIVE)throw Error('압축 파일이 너무 큽니다(320MB 제한).');
 const zip=await JSZip.loadAsync(file);const entries=Object.values(zip.files).filter(e=>!e.dir&&v12ValidName(e.name)&&e._data?.uncompressedSize<=V12_MAX_TEXTURE).map(e=>e.name);
 if(!entries.length)throw Error(file.name+'에 텍스처 PNG가 없습니다.');
 const source={id:id||'archive:'+file.name+':'+file.size,title:file.name,kind:'archive',paths:entries,count:entries.length,get:async p=>{let z=zip.file(p);if(!z)return null;return new Blob([await z.async('uint8array')],{type:'image/png'});}};
 v12AddSource(source);return entries.length;
}
async function v12ImportFiles(list){let files=[...list].filter(f=>/\.(jar|zip|png)$/i.test(f.name));if(!files.length)return v12Status('선택된 JAR·ZIP·PNG 파일이 없습니다.');let count=0,failed=[];for(let f of files.slice(0,35)){try{if(/\.png$/i.test(f.name)){const path='assets/minecraft/textures/gui/custom/'+f.name;let src={id:'png:'+f.name+':'+f.size,title:f.name,kind:'single',paths:[path],count:1,get:async()=>f};v12AddSource(src);count++;}else{count+=await v12ImportZip(f);}}catch(e){failed.push(f.name+': '+e.message);}}v12Status(`${files.length}개 파일 검사 완료 · PNG ${count.toLocaleString('ko-KR')}개 · 실패 ${failed.length}개${failed.length?' ('+failed.slice(0,2).join(', ')+')':''}`,count>0);}
$('v12MultipleFiles').onchange=async e=>{const files=[...e.target.files];e.target.value='';await v12ImportFiles(files);};
$('v12ArchiveConnect').onclick=()=>$('v12MultipleFiles').click();
$('importBtn').onclick=()=>$('v12MultipleFiles').click();
$('v12FolderFiles').onchange=async e=>{const files=[...e.target.files];e.target.value='';let candidates=files.filter(f=>/\.(jar|zip|png)$/i.test(f.name));if(candidates.length>35)candidates=candidates.filter(f=>/\/versions\/|\/resourcepacks\/|\/mods\/|\/textures\//i.test(f.webkitRelativePath)).slice(0,35);await v12ImportFiles(candidates);};
$('v12FolderFallback').onclick=()=>$('v12FolderFiles').click();
async function v12RequestPC(path){let response=await fetch('/api/'+path,{headers:{'X-MathCraft-Token':v12.token}});if(!response.ok)throw Error('PC 보조 프로그램 연결 실패 ('+response.status+')');return response.json();}
async function v12ConnectPC(refresh=false){if(!v12.token){v12Status('PC 자동 검색은 ZIP의 실행하기.bat에서 열었을 때 사용할 수 있어요. 웹앱 HTML을 직접 열었다면 JAR·ZIP이나 기기 폴더를 선택하세요.');return;}
 try{let result=await v12RequestPC(refresh?'refresh':'sources');let collection=result.sources||[];for(let s of collection){let id='pc:'+s.id;if(v12.sources.find(x=>x.id===id)&&!refresh)continue;let data=await v12RequestPC('entries?id='+encodeURIComponent(s.id));let list=(data.paths||[]).filter(v12ValidName);let source={id,title:(s.kind==='게임 버전'?'게임 ':'')+s.name,kind:'pc',paths:list,count:list.length,get:async p=>{let resp=await fetch('/api/image?id='+encodeURIComponent(s.id)+'&path='+encodeURIComponent(p),{headers:{'X-MathCraft-Token':v12.token}});return resp.ok?resp.blob():null;}};v12AddSource(source);}tip('PC에서 '+collection.length+'개 자료를 찾았어요.');if(!collection.length)v12Status('PC 도우미에 연결됐지만 설치된 게임 자료를 찾지 못했습니다. 다른 런처의 폴더를 직접 지정해 주세요.');}
 catch(e){v12Status('PC 자동 검색 연결에 실패했습니다. 실행하기.bat에서 앱을 열었는지 확인해 주세요. '+e.message);}}
$('v12PcConnect').onclick=()=>v12ConnectPC(true);
// Handles for a user-selected folder: can be remembered by browser origin if access permits.
const V12_IDB='mathcraft_v12_folder';
async function v12OpenDB(){return new Promise((resolve,reject)=>{let q=indexedDB.open(V12_IDB,1);q.onupgradeneeded=()=>q.result.createObjectStore('handles');q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error);});}
async function v12StoreHandle(handle){try{let db=await v12OpenDB();await new Promise((resolve,reject)=>{let tx=db.transaction('handles','readwrite');tx.objectStore('handles').put(handle,'last');tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)});db.close();}catch{}}
async function v12RecoverHandle(){try{let db=await v12OpenDB();let handle=await new Promise((resolve,reject)=>{let tx=db.transaction('handles');let q=tx.objectStore('handles').get('last');q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error)});db.close();return handle;}catch{return null;}}
async function v12Child(dir,key){try{return await dir.getDirectoryHandle(key)}catch{return null}}
async function v12FolderArchives(handle){let game=handle;let inner=await v12Child(game,'.minecraft');if(inner)game=inner;let out=[];
 for(let [directory,extension] of [['versions','jar'],['mods','jar'],['resourcepacks','zip']]){let h=await v12Child(game,directory);if(!h)continue;
  for await(const [name,entry] of h.entries()){
   if(out.length>=35)break;
   if(entry.kind==='file' && /\.(jar|zip)$/i.test(name)){out.push({file:await entry.getFile(),kind:directory});}
   if(directory==='versions' && entry.kind==='directory'){
    for await(const [nm,ft] of entry.entries())if(ft.kind==='file'&&/\.(jar|zip)$/i.test(nm)){out.push({file:await ft.getFile(),kind:directory});break;}
   }
  }
 }
 let r=await v12Child(game,'resourcepacks');if(r){for await(const [name,entry] of r.entries())if(entry.kind==='directory'){let count=0,dirFiles=[];let queue=[[entry,'']];while(queue.length && count<6500){let [folder,prefix]=queue.shift();for await(const [nm,obj] of folder.entries()){let rel=prefix+nm;if(obj.kind==='directory'){if(queue.length<600)queue.push([obj,rel+'/']);}else if(v12ValidName(rel)){dirFiles.push([rel,obj]);count++;}}}if(dirFiles.length)out.push({file:null,folderFiles:dirFiles,title:name,kind:'resourcepack-folder'});}}
 return out;
}
async function v12ConnectFolder(handle){v12.folderHandle=handle;v12Status('선택한 폴더에서 JAR·리소스팩·모드 파일을 검사 중입니다…');const found=await v12FolderArchives(handle);let n=0;for(let entry of found){try{if(entry.file){n+=await v12ImportZip(entry.file,'folder:'+entry.kind+':'+entry.file.name+':'+entry.file.size)}else{const list=entry.folderFiles.map(x=>x[0]);let f=new Map(entry.folderFiles);v12AddSource({id:'dir:'+entry.title,title:entry.title,kind:'folder',paths:list,count:list.length,get:async p=>{let h=f.get(p);return h?await h.getFile():null}});n+=list.length}}catch(e){console.warn('자료 검사 생략',e)}}v12Status(`선택한 폴더에서 ${found.length}개 자료, PNG ${n.toLocaleString('ko-KR')}개를 찾았습니다.`,n>0);
}
$('v12FolderConnect').onclick=async()=>{
 if(typeof showDirectoryPicker!=='function'){v12Status('이 브라우저에서는 폴더 직접 연결이 지원되지 않아요. “폴더에서 파일 선택” 또는 “JAR·ZIP 여러 개”를 이용해 주세요.');return;}
 try{let handle=v12.folderHandle;let granted=handle?await handle.queryPermission({mode:'read'}):'prompt';if(!handle||granted!=='granted'){handle=await showDirectoryPicker({id:'mathcraft-game',mode:'read'});}await v12StoreHandle(handle);await v12ConnectFolder(handle);}catch(e){if(e.name!=='AbortError')v12Status('폴더 연결 실패: '+e.message+' (안드로이드의 보호된 앱 폴더는 접근이 제한될 수 있어요.)')}
};
$('v12Refresh').onclick=async()=>{if(v12.folderHandle){try{await v12ConnectFolder(v12.folderHandle);}catch(e){v12Status('다시 검색 실패: '+e.message)}}if(v12.token)await v12ConnectPC(true);else if(!v12.folderHandle)v12Status('다시 검색할 폴더가 없습니다. 먼저 자료를 연결해 주세요.');};
(async()=>{if(v12.token)await v12ConnectPC();try{let h=await v12RecoverHandle();if(h){v12.folderHandle=h;let q=await h.queryPermission({mode:'read'});if(q==='granted')await v12ConnectFolder(h);else v12Status('이전에 연결한 폴더가 있습니다. “기기 폴더 연결”을 눌러 다시 권한을 허용해 주세요.')}}catch(e){console.warn('이전 폴더 자동 연결 불가',e)}})();
window.MC_LIBRARY_TEST={sources:()=>v12.sources.map(s=>({id:s.id,count:s.paths.length})),addSource:v12AddSource,importFiles:v12ImportFiles,refresh:v12SetPaths,search:v12RenderGallery};
