/* 수학세계 스튜디오 - Android 파일 접근 도우미. 기존 웹 편집기 기능은 그대로 사용합니다. */
(() => {
  'use strict';
  const native = window.MathCraftAndroid;
  if (!native) return;
  const sourcesAdded = new Set();
  const btnWrap = document.querySelector('.library-actions');
  if (!btnWrap) return;
  const folder = document.createElement('button');
  folder.className = 'dark';
  folder.textContent = '아메티스트 게임 폴더 선택';
  folder.title = 'Android 시스템 파일 선택기로 마인크래프트 폴더 접근을 허용합니다.';
  folder.addEventListener('click', () => native.chooseGameFolder());
  const archives = document.createElement('button');
  archives.className = 'soft';
  archives.textContent = '게임 JAR·리소스팩 선택';
  archives.addEventListener('click', () => native.chooseArchiveFiles());
  const refresh = document.createElement('button');
  refresh.className = 'soft';
  refresh.textContent = '연결된 폴더 다시 검색';
  refresh.addEventListener('click', () => native.refresh());
  btnWrap.prepend(folder, archives, refresh);
  const notice = document.createElement('div');
  notice.className = 'native-notice';
  notice.setAttribute('role','status');
  notice.textContent = '아메티스트 폴더를 선택하면 게임 이미지가 이 검색창에 자동으로 표시됩니다.';
  btnWrap.insertAdjacentElement('afterend', notice);

  function bytesFromB64(str) {
    const raw = atob(str);
    const bytes = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
    return bytes;
  }
  function registerAll() {
    try {
      const src = JSON.parse(native.listSources());
      if (!Array.isArray(src)) return;
      for (const item of src) {
        if (sourcesAdded.has(item.id)) continue;
        const paths = JSON.parse(native.listPaths(item.id));
        if (!paths.length) continue;
        window.MC_LIBRARY_TEST.addSource({
          id: 'android:' + item.id,
          title: item.title + ' (아메티스트)',
          kind: 'android',
          paths,
          count: paths.length,
          get: async path => {
            const encoded = native.textureBase64(item.id, path);
            if (!encoded) return null;
            return new Blob([bytesFromB64(encoded)], {type:'image/png'});
          }
        });
        sourcesAdded.add(item.id);
      }
      if(src.length) notice.textContent = '연결 자료 '+src.length+'개 · 이미지 검색에서 종류별 필터를 사용할 수 있습니다.';
    } catch(e) { notice.textContent = '이미지 목록 연결 실패: ' + e.message; }
  }
  window.MathCraftAndroidLibrary = {
    onLibraryChanged: registerAll,
    status: text => { notice.textContent = text; }
  };
  registerAll();

  // 브라우저 blob 다운로드 대신 Android 시스템의 '파일 저장' 창으로 내보냅니다.
  const fallbackDownload = window.download;
  if (typeof fallbackDownload === 'function') {
    window.download = (data, name, mime = 'application/zip') => {
      (async () => {
        const blob = data instanceof Blob ? data : new Blob([data], {type:mime});
        const token = native.beginExport(name);
        if (!token) throw Error('저장 준비에 실패했습니다.');
        const blockSize = 48 * 1024;
        for (let offset = 0; offset < blob.size; offset += blockSize) {
          const bytes = new Uint8Array(await blob.slice(offset,offset+blockSize).arrayBuffer());
          let binary = '';
          for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
          if (!native.exportChunk(token,btoa(binary))) throw Error('파일을 쓰지 못했습니다.');
        }
        native.finishExport(token,name,mime);
      })().catch(e => native.notifyUser('파일 저장 실패: '+e.message));
    };
  }
  const pc = document.getElementById('v12PcConnect');
  if (pc) {pc.hidden=true;}
  const hint = document.getElementById('v12SearchHint');
  if (hint) hint.textContent = '아메티스트 폴더를 연결하거나 JAR·ZIP을 선택해 원본 PNG를 검색하세요.';
})();
