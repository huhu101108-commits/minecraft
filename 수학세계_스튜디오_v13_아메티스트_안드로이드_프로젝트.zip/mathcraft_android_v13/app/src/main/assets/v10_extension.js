'use strict';
/* v10 additions. All state remains in the local browser project. */
const V10_JAVA = window.MATHCRAFT_V10_JAVA || {};
const SLOT_ROLES = {input:'추가 연산 입력',material:'소모 재료',output:'추가 출력',storage:'임시 보관'};
let v10Count=0;
function ensureV10(m){
  if(!Array.isArray(m.layers))m.layers=[];
  if(!Array.isArray(m.decoration))m.decoration=[];
  if(!m.elements||typeof m.elements!=='object')m.elements=structuredClone(STANDARD);
  return m;
}
function validDoc(d){
  if(!d||!d.machines)throw Error('지원하지 않는 프로젝트 파일입니다.');
  const p=newDoc();p.version=11;p.title=String(d.title||'나의 수학세계');
  for(const [id,m] of Object.entries(d.machines))if(p.machines[id]){
    p.machines[id]=ensureV10({...p.machines[id],...m});
    p.machines[id].elements={...structuredClone(STANDARD),...(m.elements||{})};
  }
  p.selected=p.machines[d.selected]?d.selected:'log_table';
  p.overrides=d.overrides||{};
  return p;
}
function selectedInfo(){
  const isText=chosen.startsWith('txt:'),isImage=chosen.startsWith('img:');
  let el=isText?(machine().decoration||[]).find(t=>t.id===chosen.slice(4)):
    isImage?(machine().layers||[]).find(t=>t.id===chosen.slice(4)):machine().elements[chosen];
  if(!el){chosen='inputA';el=machine().elements[chosen];}
  return {el,isText:isText&&!!el,isImage:isImage&&!!el};
}
function renderElements(){
  const list=$('elementList');list.innerHTML='';
  for(const [key,el] of Object.entries(machine().elements)){
    if(key==='toggle'&&def().modes.length<2)continue;
    const b=document.createElement('button');b.className=key===chosen?'selected':'';
    b.textContent=key.startsWith('extra_')?(SLOT_ROLES[el.role]||'추가 슬롯')+': '+el.label:el.label;
    b.onclick=()=>selectElement(key);list.appendChild(b);
  }
  for(const l of machine().layers||[]){const b=document.createElement('button');b.className=chosen==='img:'+l.id?'selected':'';b.textContent='이미지: '+l.label;b.onclick=()=>selectElement('img:'+l.id);list.appendChild(b);}
  for(const t of machine().decoration||[]){const b=document.createElement('button');b.className=chosen==='txt:'+t.id?'selected':'';b.textContent='글자: '+t.label.slice(0,10);b.onclick=()=>selectElement('txt:'+t.id);list.appendChild(b);}
}
function renderFields(){
  const {el,isText,isImage}=selectedInfo(), isExtra=chosen.startsWith('extra_');
  if(!el)return;
  $('selectedType').textContent=isText?'글자 레이어':isImage?'이미지 레이어':el.type==='button'?'작동 버튼':el.type==='output'?'결과 슬롯':isExtra?(SLOT_ROLES[el.role]||'추가 슬롯'):'입력 슬롯';
  for(const [id,key] of [['fLabel','label'],['fX','x'],['fY','y'],['fW','w'],['fH','h']])$(id).value=el[key]??0;
  $('colorRow').style.display=isText?'grid':'none';if(isText)$('fColor').value=el.color||'#333333';
  $('roleRow').style.display=isExtra?'grid':'none';if(isExtra)$('fRole').value=el.role||'material';
  $('imageFields').style.display=isImage?'grid':'none';
  if(isImage){$('fScale').value=el.scale??100;$('fAngle').value=el.angle??0;$('fOpacity').value=Math.round((el.opacity??1)*100);}
  $('fW').disabled=!isText&&!isImage; $('fH').disabled=!isText&&!isImage;
  $('removeElement').style.display=(isExtra||isImage||isText)?'block':'none';
  $('removeElement').textContent=isExtra?'추가 슬롯 삭제':isImage?'이미지 삭제':'글자 삭제';
  $('duplicateElement').disabled=!(isExtra||isImage||isText);
  $('layerUp').disabled=!isImage;$('layerDown').disabled=!isImage;
}
function drawEditor(canvas,editable=true){
  const cx=canvas.getContext('2d');cx.clearRect(0,0,canvas.width,canvas.height);
  cx.save();cx.scale(canvas.width/176,canvas.height/166);
  cx.imageSmoothingEnabled=false;drawBase(cx,machine());
  for(const layer of machine().layers||[]){
    if(layer.hidden)continue;
    const im=useImage(layer.src);if(!im)continue;
    cx.save();cx.globalAlpha=layer.opacity??1;
    cx.translate(layer.x+layer.w/2,layer.y+layer.h/2);
    cx.rotate((layer.angle||0)*Math.PI/180);
    cx.drawImage(im,-layer.w/2,-layer.h/2,layer.w,layer.h);
    cx.restore();
    if(editable&&chosen==='img:'+layer.id){cx.strokeStyle='#136e4b';cx.lineWidth=1.5;cx.strokeRect(layer.x,layer.y,layer.w,layer.h);}
  }
  for(const [id,el] of Object.entries(machine().elements)){
    if(id==='toggle'&&def().modes.length===1)continue;
    const role=el.role||(el.type==='output'?'output':'input');
    cx.fillStyle=el.type==='button'?'#667e75':role==='output'?'#c79f53':role==='storage'?'#89a1a7':role==='material'?'#9d8baf':'#515c58';
    cx.globalAlpha=.86;cx.fillRect(el.x,el.y,el.w,el.h);cx.globalAlpha=1;
    cx.strokeStyle=editable&&chosen===id?'#126b46':'#e6e6e4';cx.lineWidth=editable&&chosen===id?1.6:.7;
    cx.strokeRect(el.x+.3,el.y+.3,el.w-.6,el.h-.6);
    if(el.type==='button'){cx.fillStyle='#fff';cx.font='7px sans-serif';cx.textAlign='center';cx.fillText(el.label,el.x+el.w/2,el.y+el.h/2+2.5);cx.textAlign='start';}
    if(id.startsWith('extra_')&&editable){cx.fillStyle='#fff';cx.font='8px monospace';cx.textAlign='center';cx.fillText(({input:'+',material:'재',output:'→',storage:'보'})[role]||'+',el.x+el.w/2,el.y+11);cx.textAlign='left';}
  }
  for(const txt of machine().decoration||[]){if(editable&&chosen==='txt:'+txt.id){cx.strokeStyle='#136e4b';cx.lineWidth=1;cx.strokeRect(txt.x,txt.y,txt.w||30,txt.h||12);}}
  cx.restore();
}
function refresh(){
  if(!doc.machines[doc.selected])doc.selected='log_table';
  ensureV10(machine());
  $('machineSelect').value=doc.selected;$('mobileMachineSelect').value=doc.selected;
  $('stageName').textContent=def().name;
  renderElements();renderFields();renderLogic();draw();
  const report=layoutWarnings();$('layoutValidation').textContent=report.length?`확인할 사항: ${report.join(' / ')}`:`추가 슬롯 ${extraEntries().length}개 · 이미지 ${machine().layers.length}개 · 배치 정상`;
  $('layoutValidation').classList.toggle('warning',!!report.length);
}
function extraEntries(m=machine()){return Object.entries(m.elements).filter(([key])=>key.startsWith('extra_'));}
function layoutWarnings(){
  let warnings=[], m=machine(),all=Object.entries(m.elements);
  for(const [name,e] of all){
    if(e.x<0||e.y<0||e.x+e.w>176||e.y+e.h>166)warnings.push(name+' 영역 밖');
    if((e.type==='slot'||e.type==='output')&&e.w!==18||((e.type==='slot'||e.type==='output')&&e.h!==18))warnings.push('실제 슬롯 크기는 18×18 고정');
  }
  const sl=all.filter(([_,e])=>e.type==='slot'||e.type==='output');
  for(let a=0;a<sl.length;a++)for(let b=a+1;b<sl.length;b++){
    const x=sl[a][1],y=sl[b][1];
    if(Math.abs(x.x-y.x)<16&&Math.abs(x.y-y.y)<16){warnings.push('슬롯 겹침');a=sl.length;break;}
  }
  if(extraEntries().length>24)warnings.push('슬롯은 24개 이하 권장');
  return [...new Set(warnings)];
}
function addExtraSlot(role){
  if(extraEntries().length>=24)return tip('추가 슬롯은 한 작업대당 24개까지 지원합니다.');
  const positions=[];
  for(const y of [18,57,38])for(const x of [6,46,96,116,139,66,26])positions.push({x,y});
  const occupied=Object.values(machine().elements).filter(e=>e.type==='slot'||e.type==='output'||e.type==='button');
  const free=positions.find(p=>!occupied.some(e=>p.x<e.x+e.w+1&&p.x+18+1>e.x&&p.y<e.y+e.h+1&&p.y+18+1>e.y))||{x:8,y:18};
  hist();let key='extra_'+Date.now().toString(36)+'_'+(++v10Count).toString(36);
  machine().elements[key]={type:role==='output'?'output':'slot',role,label:SLOT_ROLES[role],x:free.x,y:free.y,w:18,h:18};
  chosen=key;changed();
}
$('addInput').onclick=()=>addExtraSlot('input');
$('addMaterial').onclick=()=>addExtraSlot('material');
$('addOutput').onclick=()=>addExtraSlot('output');
$('addStorage').onclick=()=>addExtraSlot('storage');
$('addLayer').onclick=()=>chooseFile('.png,image/png',async f=>{
  hist();const src=await toData(f);const id='l'+Date.now().toString(36)+'_'+(++v10Count);
  ensureV10(machine()).layers.push({id,src,label:f.name.replace(/\.png$/i,''),x:30,y:25,w:40,h:40,scale:100,angle:0,opacity:1});
  chosen='img:'+id;changed();tip('이미지를 올렸어요. 화면에서 드래그해 배치하세요.');
});
$('fRole').onchange=e=>{if(!chosen.startsWith('extra_'))return;hist();let el=selectedInfo().el;el.role=e.target.value;el.type=el.role==='output'?'output':'slot';changed();};
$('fScale').onchange=e=>{let {el,isImage}=selectedInfo();if(!isImage)return;hist();let scale=Math.max(5,Math.min(500,+e.target.value||100)),ratio=scale/(el.scale||100);el.w=Math.max(8,Math.round(el.w*ratio));el.h=Math.max(8,Math.round(el.h*ratio));el.scale=scale;changed();};
$('fAngle').oninput=e=>{let {el,isImage}=selectedInfo();if(!isImage)return;el.angle=+e.target.value||0;draw();saveSoon();};
$('fOpacity').oninput=e=>{let {el,isImage}=selectedInfo();if(!isImage)return;el.opacity=(+e.target.value||0)/100;draw();saveSoon();};
$('replaceLayer').onclick=()=>{if(!chosen.startsWith('img:'))return;chooseFile('.png,image/png',async f=>{hist();const el=selectedInfo().el;el.src=await toData(f);el.label=f.name;changed();});};
$('removeElement').onclick=()=>{
  if(['inputA','inputB','output','run','toggle'].includes(chosen))return;
  hist();
  if(chosen.startsWith('img:'))machine().layers=machine().layers.filter(l=>'img:'+l.id!==chosen);
  else if(chosen.startsWith('txt:'))machine().decoration=machine().decoration.filter(t=>'txt:'+t.id!==chosen);
  else delete machine().elements[chosen];
  chosen='inputA';changed();
};
$('duplicateElement').onclick=()=>{
  const {el,isImage,isText}=selectedInfo();if(!(isImage||isText||chosen.startsWith('extra_')))return;
  hist();const clone=structuredClone(el);clone.x=Math.min(176-clone.w,clone.x+8);clone.y=Math.min(166-clone.h,clone.y+8);
  const id='d'+Date.now().toString(36)+'_'+(++v10Count);
  if(isImage){clone.id=id;machine().layers.push(clone);chosen='img:'+id;}
  else if(isText){clone.id=id;machine().decoration.push(clone);chosen='txt:'+id;}
  else {const key='extra_'+id;machine().elements[key]=clone;chosen=key;}
  changed();
};
for(const [button,delta] of [['layerUp',1],['layerDown',-1]])$(button).onclick=()=>{
  if(!chosen.startsWith('img:'))return;
  const list=machine().layers,i=list.findIndex(l=>'img:'+l.id===chosen),j=i+delta;
  if(i<0||j<0||j>=list.length)return;
  hist();[list[i],list[j]]=[list[j],list[i]];changed();
};
$('alignSlots').onclick=()=>{const extras=extraEntries();if(!extras.length)return tip('추가한 슬롯이 없습니다.');hist();extras.forEach(([k,el],i)=>{el.x=8+(i%8)*19;el.y=20+Math.floor(i/8)*19;el.w=el.h=18;});changed();tip('추가 슬롯을 격자에 정렬했어요.');};
$('resetLayout').onclick=()=>{if(!confirm('현재 작업대의 슬롯·이미지·글자를 모두 기본 상태로 되돌릴까요?'))return;hist();machine().elements=structuredClone(STANDARD);machine().layers=[];machine().decoration=[];changed();};
$('editor').addEventListener('keydown',e=>{
  if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key))return;
  e.preventDefault();let {el}=selectedInfo();if(!el)return;
  hist();let step=e.shiftKey?4:1;doMove(el,el.x+((e.key==='ArrowRight')-(e.key==='ArrowLeft'))*step,el.y+((e.key==='ArrowDown')-(e.key==='ArrowUp'))*step);changed();
});
$('editor').tabIndex=0;
// Numeric coordinate editing remains available for precision after touch moves.
function machineJava(){
  const out=['package com.mathcraft.generated;','','public final class MachineLayouts {','  private MachineLayouts() {}','  public static final MachineDefinition[] ALL = {'];
  const arr=[];
  for(const m of MACHINES){
    const s=doc.machines[m.id].elements;
    const p=k=>{let e=s[k];return e.type==='button'?`new int[]{${e.x},${e.y},${e.w},${e.h}}`:`new int[]{${e.x},${e.y}}`;};
    const extra=extraEntries(doc.machines[m.id]);
    const positions=extra.map(([_,v])=>`new int[]{${v.x},${v.y}}`).join(',');
    const roles=extra.map(([_,v])=>`"${v.role||'material'}"`).join(',');
    arr.push(`    new MachineDefinition("${m.id}", MachineType.${m.type}, ${p('inputA')}, ${p('inputB')}, ${p('output')}, ${p('run')}, ${p('toggle')}, "${m.id==='formula_table'?'a^2+b':'a*b'}", new int[][]{${positions}}, new String[]{${roles}})`);
  }
  return out.concat(arr.join(',\n'),['  };','}']).join('\n')+'\n';
}
async function guiBytes(id){
  const m=ensureV10(doc.machines[id]),d=MACHINES.find(x=>x.id===id);
  await waitImages([m.background,...m.layers.map(l=>l.src)]);
  const c=document.createElement('canvas');c.width=c.height=256;const cx=c.getContext('2d');cx.imageSmoothingEnabled=false;
  cx.fillStyle='#d4d2cb';cx.fillRect(0,0,176,166);
  const bg=m.background?useImage(m.background):null;
  if(bg)cx.drawImage(bg,0,0,176,166);
  else{
    cx.fillStyle='#bcb8b2';cx.fillRect(0,0,176,166);cx.fillStyle='#ece9e2';cx.fillRect(4,4,168,158);
    cx.strokeStyle='#68625c';cx.strokeRect(.5,.5,175,165);cx.fillStyle='#333';cx.font='10px sans-serif';cx.fillText(d.name,8,14);
    for(let r=0;r<3;r++)for(let i=0;i<9;i++){cx.fillStyle='#a39f97';cx.fillRect(8+i*18,84+r*18,18,18);cx.fillStyle='#dfdad0';cx.fillRect(9+i*18,85+r*18,16,16);}
    for(let i=0;i<9;i++){cx.fillStyle='#a39f97';cx.fillRect(8+i*18,142,18,18);cx.fillStyle='#dfdad0';cx.fillRect(9+i*18,143,16,16);}
  }
  for(const l of m.layers){if(l.hidden)continue;let img=useImage(l.src);if(!img)continue;cx.save();cx.globalAlpha=l.opacity??1;cx.translate(l.x+l.w/2,l.y+l.h/2);cx.rotate((l.angle||0)*Math.PI/180);cx.drawImage(img,-l.w/2,-l.h/2,l.w,l.h);cx.restore();}
  // Slot backgrounds are painted into the PNG; actual clickable slots are in the Java menu.
  for(const [key,el] of Object.entries(m.elements))if(el.type==='slot'||el.type==='output'){
    cx.fillStyle='#807c74';cx.fillRect(el.x,el.y,18,18);cx.fillStyle='#bdb8ae';cx.fillRect(el.x+1,el.y+1,16,16);cx.fillStyle='#d9d4cb';cx.fillRect(el.x+2,el.y+2,14,14);
  }
  for(const t of m.decoration){cx.fillStyle=t.color||'#333';cx.font=(t.font||8)+'px sans-serif';cx.fillText(t.label,t.x,t.y);}
  return new Uint8Array(await (await new Promise(r=>c.toBlob(r,'image/png'))).arrayBuffer());
}
async function createMod(){
  if(!window.MATHCRAFT_TEMPLATE_B64)throw Error('내장 Fabric 프로젝트가 없습니다.');
  let z=await JSZip.loadAsync(b64bytes(window.MATHCRAFT_TEMPLATE_B64));
  z.file('src/main/java/com/mathcraft/generated/MachineLayouts.java',machineJava());
  for(let [name,src] of Object.entries(V10_JAVA))z.file('src/main/java/com/mathcraft/generated/'+name,src);
  for(const m of MACHINES)z.file('src/main/resources/assets/mathcraft/textures/gui/'+m.id+'.png',await guiBytes(m.id));
  z.file('편집기_슬롯과_이미지.json',JSON.stringify(doc.machines,null,2));
  z.file('README_추가슬롯_한글.txt',`수학세계 제작소 v10 / Minecraft Java 1.21.1 / Fabric\n\n추가 슬롯 지원:\n연산 입력 - 로그 작업대의 곱셈 또는 나눗셈 인수로 사용. 다른 기계에서는 1개 소모하는 필수 재료.\n소모 재료 - 실행 성공 시 슬롯에서 1개 소모.\n임시 보관 - 연산과 무관. 화면을 닫으면 플레이어 인벤토리로 돌려줌.\n추가 출력 - 결과를 나누어 받을 수 있음. 화면을 닫으면 남은 출력은 보관권으로 지급.\n출력 슬롯에는 아이템을 넣을 수 없음. 출력 아이템의 시프트클릭은 비활성화.\n\n주의: 데이터팩만으로 커스텀 슬롯을 추가하거나 위치를 바꿀 수 없음. Fabric 소스를 빌드해야 함.\n이 프로젝트는 코드/구조 검사만 수행했고 Minecraft 실게임 빌드 검증은 별도로 필요.\n`);
  return z.generateAsync({type:'blob',compression:'DEFLATE'});
}
// Persist new projects separately while importing v9 JSON normally.
let v10Saved=null;try{v10Saved=localStorage.getItem('mathcraft_studio_v10');}catch(e){}
if(v10Saved){try{doc=validDoc(JSON.parse(v10Saved));}catch(e){tip('이전 편집 상태를 읽지 못했습니다.');}}
const _oldSaveSoon=saveSoon;
function saveSoon(){clearTimeout(saveTimer);$('saveState').textContent='저장 중';saveTimer=setTimeout(()=>{try{localStorage.setItem('mathcraft_studio_v10',JSON.stringify(doc));$('saveState').textContent='자동 저장됨';}catch(e){$('saveState').textContent='프로젝트 파일로 저장하세요';}},450);}
window.MC_TEST={getDoc:()=>doc,setMachine:id=>{doc.selected=id;refresh();},getFabricLayout:machineJava,createDP,createRP,createMod,layoutWarnings,addExtraSlot};
refresh();
